document.getElementById('profile-form').addEventListener('submit', function (e) {
  e.preventDefault();

  const displayName = document.getElementById('display-name').value;
  const bio = document.getElementById('bio').value;
  const profilePicture = document.getElementById('profile-picture').files[0];
  const backgroundImage = document.getElementById('background-image').files[0];
  const backgroundColor = document.getElementById('background-color').value;
  const textColor = document.getElementById('text-color').value;
  const fontStyle = document.getElementById('font-style').value;
  const fontSize = document.getElementById('font-size').value;
  const borderColor = document.getElementById('border-color').value;
  const shadowEffect = document.getElementById('shadow-effect').value;
  const backgroundMusicFile = document.getElementById('background-music-file').files[0];

  const profileBackground = document.getElementById('profile-background');
  const profilePicPreview = document.getElementById('profile-pic-preview');
  const profileName = document.getElementById('profile-name');
  const profileBio = document.getElementById('profile-bio');
  const backgroundMusic = document.getElementById('background-music');

  // Update text content
  if (displayName) profileName.textContent = displayName;
  if (bio) profileBio.textContent = bio;

  // Apply styles
  profileName.style.color = textColor;
  profileBio.style.color = textColor;
  profileName.style.fontFamily = fontStyle;
  profileBio.style.fontFamily = fontStyle;
  profileName.style.fontSize = fontSize;
  profileBio.style.fontSize = fontSize;
  profileBackground.style.backgroundColor = backgroundColor;
  profileBackground.style.borderColor = borderColor;
  profileBackground.style.borderWidth = "2px";
  profileBackground.style.borderStyle = "solid";

  // Apply shadow effect
  if (shadowEffect === "small") {
    profileBackground.style.boxShadow = "2px 2px 8px rgba(0, 0, 0, 0.3)";
  } else if (shadowEffect === "large") {
    profileBackground.style.boxShadow = "5px 5px 15px rgba(0, 0, 0, 0.5)";
  } else {
    profileBackground.style.boxShadow = "none";
  }

  // Handle profile picture upload
  if (profilePicture) {
    const reader = new FileReader();
    reader.onload = function (e) {
      profilePicPreview.src = e.target.result;
      profilePicPreview.style.display = "block";
    };
    reader.readAsDataURL(profilePicture);
  }

  // Handle background image upload
  if (backgroundImage) {
    const reader = new FileReader();
    reader.onload = function (e) {
      profileBackground.style.backgroundImage = `url(${e.target.result})`;
    };
    reader.readAsDataURL(backgroundImage);
  } else {
    profileBackground.style.backgroundImage = "none";
  }

  // Handle background music upload
  if (backgroundMusicFile) {
    const musicReader = new FileReader();
    musicReader.onload = function (e) {
      backgroundMusic.src = e.target.result;
      backgroundMusic.style.display = "block";
    };
    musicReader.readAsDataURL(backgroundMusicFile);
  }
});

// Reset button functionality
document.getElementById('reset-button').addEventListener('click', function () {
  location.reload();
});
